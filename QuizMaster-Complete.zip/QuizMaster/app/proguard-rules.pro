# Add project specific ProGuard rules here.
# Keep data model used for JSON parsing
-keep class com.quizmaster.trivia.model.** { *; }

# Google Mobile Ads SDK
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.ads.**
