package com.quizmaster.trivia.ui

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.quizmaster.trivia.R
import com.quizmaster.trivia.databinding.ActivityRequestsListBinding
import com.quizmaster.trivia.utils.PrefsManager

/**
 * Admin-only screen showing all pending redeem requests submitted on this
 * device. Admins can view contact info, mark requests as complete, and
 * optionally paste a generated code (the actual code generation happens
 * outside the app, or manually by the admin - this screen just marks
 * "I've sent them a code, so close this request out").
 *
 * Only visible when signed in as the admin account.
 */
class RequestsListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRequestsListBinding
    private lateinit var adapter: AdminRequestsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRequestsListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!PrefsManager.isAdmin(this)) {
            finish()
            return
        }

        adapter = AdminRequestsAdapter(emptyList()) { requestId ->
            onMarkComplete(requestId)
        }
        binding.rvRequests.layoutManager = LinearLayoutManager(this)
        binding.rvRequests.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val requests = PrefsManager.getRedeemRequests(this)
        adapter.updateData(requests)
        binding.tvEmpty.visibility = if (requests.isEmpty()) View.VISIBLE else View.GONE
        binding.rvRequests.visibility = if (requests.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun onMarkComplete(requestId: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.mark_request_complete)
            .setMessage(R.string.mark_request_complete_message)
            .setPositiveButton(R.string.yes) { _, _ ->
                PrefsManager.markRequestFulfilled(this, requestId)
                Toast.makeText(this, R.string.request_marked_complete, Toast.LENGTH_SHORT).show()
                refresh()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
