package com.quizmaster.trivia.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.quizmaster.trivia.R
import com.quizmaster.trivia.databinding.ActivityRedeemBinding
import com.quizmaster.trivia.utils.PrefsManager

/**
 * Player's redemption screen. At 1000 coins, they can request a code.
 * Requests are stored locally on the device - the admin (signed into this
 * same device) can view all requests by tapping "View Requests" from the
 * home screen and marking them complete once a code is sent.
 */
class RedeemActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRedeemBinding
    private lateinit var adapter: RedeemRequestAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRedeemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = RedeemRequestAdapter(emptyList()) { requestId ->
            PrefsManager.markRequestFulfilled(this, requestId)
            refresh()
        }
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = adapter

        binding.btnRedeem.setOnClickListener { onRequestClicked() }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val coins = PrefsManager.getCoins(this)
        val threshold = PrefsManager.redeemThreshold()

        binding.tvBalance.text = coins.toString()
        binding.tvProgressLabel.text = getString(
            R.string.redeem_progress_format,
            coins.coerceAtMost(threshold),
            threshold
        )
        binding.btnRedeem.text = getString(R.string.request_button_format, threshold)
        binding.btnRedeem.isEnabled = coins >= threshold
        binding.btnRedeem.alpha = if (coins >= threshold) 1f else 0.5f

        binding.progressTrack.post {
            val fraction = coins.coerceAtMost(threshold).toFloat() / threshold
            val width = (binding.progressTrack.width * fraction).toInt()
            val params = binding.progressFill.layoutParams
            params.width = width
            binding.progressFill.layoutParams = params
        }

        val requests = PrefsManager.getRedeemRequests(this)
        adapter.updateData(requests)
        binding.tvNoCodes.visibility = if (requests.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.rvHistory.visibility = if (requests.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun onRequestClicked() {
        val coins = PrefsManager.getCoins(this)
        val threshold = PrefsManager.redeemThreshold()
        if (coins < threshold) {
            Toast.makeText(this, getString(R.string.not_enough_coins, threshold), Toast.LENGTH_SHORT).show()
            return
        }

        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            hint = getString(R.string.contact_dialog_hint)
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.contact_dialog_title)
            .setMessage(R.string.contact_dialog_message)
            .setView(input)
            .setPositiveButton(R.string.ok) { _, _ ->
                val contact = input.text.toString().trim()
                if (contact.isEmpty()) {
                    Toast.makeText(this, getString(R.string.contact_dialog_hint), Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                submitRequest(contact)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun submitRequest(contact: String) {
        val request = PrefsManager.submitRedeemRequest(this, contact) ?: return
        refresh()
        Toast.makeText(this, getString(R.string.request_submitted), Toast.LENGTH_LONG).show()
    }
}
