package com.quizmaster.trivia

import android.app.Application
import com.quizmaster.trivia.utils.AdManager

class QuizApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AdManager.init(this)
    }
}
