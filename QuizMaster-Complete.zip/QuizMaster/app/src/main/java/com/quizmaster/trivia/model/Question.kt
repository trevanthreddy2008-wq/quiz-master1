package com.quizmaster.trivia.model

/**
 * A single quiz question.
 *
 * @param id unique identifier, e.g. "L1Q3"
 * @param level the level (1-100) this question belongs to
 * @param category display category, e.g. "Geography", "Math"
 * @param question the question text
 * @param options exactly 4 possible answers
 * @param correctIndex index (0-3) into [options] that is correct
 * @param difficulty "easy" | "medium" | "hard" | "expert"
 */
data class Question(
    val id: String,
    val level: Int,
    val category: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val difficulty: String
)
