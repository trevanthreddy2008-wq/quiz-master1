package com.quizmaster.trivia.data

import android.content.Context
import com.quizmaster.trivia.model.Question
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Loads the 1000-question bank bundled at assets/questions.json and serves
 * it grouped by level. The whole bank (~1000 small objects) is tiny, so we
 * just parse it once and keep it in memory for the life of the process.
 */
object QuestionRepository {

    private var allQuestions: List<Question>? = null

    fun getQuestionsForLevel(context: Context, level: Int): List<Question> {
        return ensureLoaded(context).filter { it.level == level }
    }

    fun totalLevels(context: Context): Int {
        return ensureLoaded(context).maxOfOrNull { it.level } ?: 0
    }

    private fun ensureLoaded(context: Context): List<Question> {
        allQuestions?.let { return it }

        val json = context.assets.open("questions.json").use { stream ->
            BufferedReader(InputStreamReader(stream)).readText()
        }

        val array = JSONArray(json)
        val result = ArrayList<Question>(array.length())

        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val optionsArray = obj.getJSONArray("options")
            val options = ArrayList<String>(optionsArray.length())
            for (j in 0 until optionsArray.length()) {
                options.add(optionsArray.getString(j))
            }

            result.add(
                Question(
                    id = obj.getString("id"),
                    level = obj.getInt("level"),
                    category = obj.getString("category"),
                    question = obj.getString("question"),
                    options = options,
                    correctIndex = obj.getInt("correctIndex"),
                    difficulty = obj.getString("difficulty")
                )
            )
        }

        allQuestions = result
        return result
    }
}
