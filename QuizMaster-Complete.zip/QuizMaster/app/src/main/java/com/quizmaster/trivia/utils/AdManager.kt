package com.quizmaster.trivia.utils

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Wraps AdMob interstitial ad loading/showing.
 */
object AdManager {

    private const val TAG = "AdManager"
    private const val INTERSTITIAL_UNIT_ID = "ca-app-pub-8353500809359551/6447569405"

    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        MobileAds.initialize(context) { }
    }

    fun preload(context: Context) {
        if (interstitialAd != null || isLoading) return
        isLoading = true
        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            INTERSTITIAL_UNIT_ID,
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Interstitial failed to load: ${error.message}")
                    interstitialAd = null
                    isLoading = false
                }
            }
        )
    }

    /**
     * Shows the preloaded interstitial if one is ready. Either way,
     * [onComplete] is ALWAYS invoked exactly once - if no ad is ready
     * (e.g. no internet, fill rate miss) we don't block the player's
     * progress or reward; we just skip straight to onComplete.
     */
    fun showInterstitial(activity: Activity, onComplete: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) {
            onComplete()
            // Try to have one ready for next time.
            preload(activity)
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                preload(activity)
                onComplete()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitialAd = null
                preload(activity)
                onComplete()
            }
        }
        ad.show(activity)
    }
}
